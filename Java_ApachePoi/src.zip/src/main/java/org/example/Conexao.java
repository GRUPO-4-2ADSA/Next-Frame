package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    private static final String URL = "jdbc:mysql://localhost:3306/nextFrame";
    private static final String USUARIO = "root";
    private static final String SENHA = "Chawosz12@";

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA); // DriverManager é uma classe gerencia conexões com bancos de dados por meio do JDBC.
    }




}
